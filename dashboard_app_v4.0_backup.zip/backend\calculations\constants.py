COMPONENTS=['Paraffin','I-Paraffins','Aromatics','Naphthenes','Olefins','Unknown']
CARBON_NUMBERS=list(range(1,16))
HEADER_SHEET='HEADER'
CARBON_SHEET='CARBON_TABULAR(%WGT)'
COMPONENT_LIST_SHEET='COMPONENT_LIST'
