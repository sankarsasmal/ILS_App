const EXCLUDED_COLUMNS = new Set([
    "01i14FIC01",
    "01i14FIC02",
    "01i14FIC03",
    "01i14FIC04",
    "01i14FIC05",
    "01i14FIC06",
    "01i14FIC07",
    "01i14FIC08"
]);

const calcState = {
    allRows: [],
    columns: [],
    sourceFile: '',
    activeSubtab: 'base_table'
};

const calc$ = selector => document.querySelector(selector);

const formatCalcValue = value => {
    if (value === null || value === undefined || value === '') return '';
    if (typeof value === 'number' && Number.isFinite(value)) {
        return Number.isInteger(value) ? String(value) : value.toFixed(2);
    }
    const num = Number(value);
    if (!isNaN(num) && String(value).trim() !== '' && !String(value).includes('-') && !String(value).includes(':')) {
        return Number.isInteger(num) ? String(num) : num.toFixed(2);
    }
    return String(value);
};

function parseCalcDateTime(val) {
    if (!val) return null;
    const str = String(val).trim();
    const isoMatch = str.match(/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (isoMatch) {
        return new Date(
            Number(isoMatch[1]),
            Number(isoMatch[2]) - 1,
            Number(isoMatch[3]),
            Number(isoMatch[4]),
            Number(isoMatch[5]),
            Number(isoMatch[6] || 0)
        );
    }
    const dmyMatch = str.match(/^(\d{2})[./-](\d{2})[./-](\d{4})[ T](\d{2}):(\d{2})(?::(\d{2}))?$/);
    if (dmyMatch) {
        return new Date(
            Number(dmyMatch[3]),
            Number(dmyMatch[2]) - 1,
            Number(dmyMatch[1]),
            Number(dmyMatch[4]),
            Number(dmyMatch[5]),
            Number(dmyMatch[6] || 0)
        );
    }
    const d = new Date(str.replace(' ', 'T'));
    return Number.isNaN(d.getTime()) ? null : d;
}

function parseFilterTimestamp(val) {
    if (!val) return null;
    const d = parseCalcDateTime(val) || new Date(val);
    const t = d ? d.getTime() : NaN;
    return Number.isNaN(t) ? null : t;
}

function showCalcError(msg = '') {
    const el = calc$('#calcError');
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('show', Boolean(msg));
}

function updateKpis() {
    if (calc$('#kpiRecords')) calc$('#kpiRecords').textContent = calcState.allRows.length;
    if (calc$('#kpiActiveParams')) calc$('#kpiActiveParams').textContent = calcState.columns.length || 17;
    if (calc$('#kpiExcludedParams')) calc$('#kpiExcludedParams').textContent = 8;
    if (calc$('#kpiSource')) {
        if (calcState.sourceFile) {
            calc$('#kpiSource').textContent = calcState.sourceFile.split(/[\\/]/).pop();
            calc$('#kpiSource').title = calcState.sourceFile;
        } else if (calcState.allRows.length) {
            calc$('#kpiSource').textContent = 'Online Sync';
        } else {
            calc$('#kpiSource').textContent = '—';
        }
    }
}

function renderReactorFilter() {
    const filterEl = calc$('#calcReactorFilter');
    if (!filterEl) return;
    const current = filterEl.value;
    const reactors = [...new Set(calcState.allRows.map(r => String(r.Reactor ?? '')).filter(Boolean))].sort();
    filterEl.innerHTML = '<option value="">All reactors</option>' + reactors.map(r => `<option value="${r}"${r === current ? ' selected' : ''}>${r}</option>`).join('');
}

function renderBaseTable() {
    const thead = calc$('#calcThead');
    const tbody = calc$('#calcTbody');
    const empty = calc$('#calcEmpty');
    const badge = calc$('#calcDateBadge');
    if (!thead || !tbody) return;

    if (!calcState.allRows.length || !calcState.columns.length) {
        thead.innerHTML = '';
        tbody.innerHTML = '';
        if (empty) empty.style.display = 'block';
        if (badge) badge.textContent = '';
        return;
    }

    const query = (calc$('#calcSearch')?.value || '').toLowerCase().trim();
    const reactor = calc$('#calcReactorFilter')?.value || '';
    const fromVal = calc$('#calcFrom')?.value || '';
    const toVal = calc$('#calcTo')?.value || '';

    const fromTime = parseFilterTimestamp(fromVal);
    let toTime = parseFilterTimestamp(toVal);
    if (toTime !== null && toVal.length === 16) {
        toTime += 59999;
    }

    const filtered = calcState.allRows.filter(row => {
        if (reactor && String(row.Reactor) !== reactor) return false;

        if (fromTime !== null || toTime !== null) {
            const rowDt = parseCalcDateTime(row.DateTime);
            const rowTime = rowDt ? rowDt.getTime() : null;
            if (rowTime !== null) {
                if (fromTime !== null && rowTime < fromTime) return false;
                if (toTime !== null && rowTime > toTime) return false;
            }
        }

        if (query) {
            return Object.values(row).join(' ').toLowerCase().includes(query);
        }
        return true;
    });

    thead.innerHTML = calcState.columns.map(col => `<th>${col}</th>`).join('');
    tbody.innerHTML = filtered.map(row => {
        const cells = calcState.columns.map(col => {
            const val = row[col];
            if (col === 'DateTime') {
                return `<td style="font-weight: 600; white-space: nowrap;">${val ?? ''}</td>`;
            }
            if (col === 'Reactor') {
                return `<td style="text-align: center; font-weight: 700; color: var(--primary-accent, #2563eb);">${val ?? ''}</td>`;
            }
            return `<td style="text-align: center;">${formatCalcValue(val)}</td>`;
        }).join('');
        return `<tr>${cells}</tr>`;
    }).join('');

    if (empty) empty.style.display = filtered.length ? 'none' : 'block';

    if (badge) {
        if (fromVal || toVal || query || reactor) {
            badge.textContent = `Showing ${filtered.length} of ${calcState.allRows.length} records`;
        } else {
            badge.textContent = `${calcState.allRows.length} records`;
        }
    }
}

function loadFromOnlineState() {
    try {
        const raw = sessionStorage.getItem('dhaOnlineState');
        if (!raw) return false;
        const onlineState = JSON.parse(raw);
        if (!onlineState || !Array.isArray(onlineState.rows) || !onlineState.rows.length) {
            return false;
        }

        let rawCols = onlineState.columns;
        if (!Array.isArray(rawCols) || !rawCols.length) {
            rawCols = Object.keys(onlineState.rows[0]);
        }

        // Filter out the 8 specified FIC columns
        calcState.columns = rawCols.filter(col => !EXCLUDED_COLUMNS.has(col));

        // Copy records and strip the 8 excluded columns
        calcState.allRows = onlineState.rows.map(row => {
            const copy = {};
            for (let i = 0; i < calcState.columns.length; i += 1) {
                const col = calcState.columns[i];
                copy[col] = row[col];
            }
            return copy;
        });

        calcState.sourceFile = onlineState.path || '';

        // Restore date filters if present
        if (onlineState.from && calc$('#calcFrom')) calc$('#calcFrom').value = onlineState.from;
        if (onlineState.to && calc$('#calcTo')) calc$('#calcTo').value = onlineState.to;

        const sharedDates = JSON.parse(sessionStorage.getItem('dhaDateTimeFilter') || 'null');
        if (sharedDates) {
            if (sharedDates.from && calc$('#calcFrom')) calc$('#calcFrom').value = sharedDates.from;
            if (sharedDates.to && calc$('#calcTo')) calc$('#calcTo').value = sharedDates.to;
        }

        if (calc$('#calcSummary')) {
            const fileName = calcState.sourceFile ? calcState.sourceFile.split(/[\\/]/).pop() : 'Online Analysis';
            calc$('#calcSummary').textContent = `Synchronized with ${fileName} · ${calcState.allRows.length} records · 8 FIC columns excluded (${calcState.columns.length} columns displayed)`;
        }

        updateKpis();
        renderReactorFilter();
        renderBaseTable();
        return true;
    } catch (err) {
        console.error('Failed to load online state for Base table:', err);
        return false;
    }
}

async function syncDirectFromFile() {
    showCalcError();
    const btn = calc$('#calcSyncBtn');
    const oldText = btn ? btn.textContent : '';
    if (btn) {
        btn.disabled = true;
        btn.textContent = 'Syncing...';
    }
    if (calc$('#calcStatus')) calc$('#calcStatus').textContent = 'Syncing...';

    try {
        // 1. Try reading directly from session storage first
        if (loadFromOnlineState()) {
            if (calc$('#calcStatus')) calc$('#calcStatus').textContent = 'Ready';
            return;
        }

        // 2. Otherwise try loading via backend API with common online analysis file path
        let targetPath = '';
        try {
            const sRes = await fetch('/api/settings');
            const sData = await sRes.json();
            if (sData.online_file) targetPath = sData.online_file;
        } catch (e) {}

        const candidatePaths = [
            targetPath,
            'Result_10Aug26.txt',
            'Data/Result_10Aug26.txt',
            'C:\\Users\\sanka\\Desktop\\ILS_App\\Result_10Aug26.txt',
            'C:\\Users\\sanka\\Desktop\\ILS_App\\Data\\Result_10Aug26.txt'
        ].filter(Boolean);

        let data = null;
        for (let i = 0; i < candidatePaths.length; i += 1) {
            try {
                const res = await fetch('/api/process-calculation-base', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ path: candidatePaths[i] })
                });
                if (res.ok) {
                    data = await res.json();
                    if (data && Array.isArray(data.rows) && data.rows.length) break;
                }
            } catch (e) {}
        }

        if (data && Array.isArray(data.rows)) {
            calcState.columns = data.columns.filter(c => !EXCLUDED_COLUMNS.has(c));
            calcState.allRows = data.rows;
            calcState.sourceFile = data.source_file || '';

            updateKpis();
            renderReactorFilter();
            renderBaseTable();

            if (calc$('#calcSummary')) {
                calc$('#calcSummary').textContent = `Loaded ${data.record_count} records from ${data.source_file} · 8 FIC columns excluded (${calcState.columns.length} active columns)`;
            }
            if (calc$('#calcStatus')) calc$('#calcStatus').textContent = 'Ready';
        } else {
            showCalcError('No Online Analysis data loaded yet. Please import a SystemTxt file on the Online Analysis page.');
            if (calc$('#calcStatus')) calc$('#calcStatus').textContent = 'Ready';
        }
    } catch (err) {
        showCalcError(err.message || 'Failed to sync Online Analysis data.');
        if (calc$('#calcStatus')) calc$('#calcStatus').textContent = 'Failed';
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = oldText;
        }
    }
}

function exportBaseTableCsv() {
    if (!calcState.allRows.length || !calcState.columns.length) {
        showCalcError('No data available to export.');
        return;
    }

    const header = calcState.columns.join(',');
    const rows = calcState.allRows.map(row =>
        calcState.columns.map(col => {
            const val = row[col] ?? '';
            const str = String(val).replace(/"/g, '""');
            return str.includes(',') || str.includes('"') || str.includes('\n') ? `"${str}"` : str;
        }).join(',')
    );

    const csvContent = [header, ...rows].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `Base_Table_Reactor_Conditions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
}

function switchSubtab(tabName) {
    calcState.activeSubtab = tabName;
    document.querySelectorAll('.table-tabs .table-tab').forEach(btn => {
        const isActive = btn.dataset.subtab === tabName;
        btn.classList.toggle('active', isActive);
        btn.setAttribute('aria-selected', String(isActive));
    });

    const basePanel = calc$('#baseTablePanel');
    if (basePanel) {
        basePanel.hidden = (tabName !== 'base_table');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    // 1. Initial attempt to load from Online Analysis session state
    const hasData = loadFromOnlineState();

    // If not loaded, automatically attempt direct sync from source file
    if (!hasData) {
        syncDirectFromFile();
    }

    // 2. Wire event listeners
    if (calc$('#calcSearch')) calc$('#calcSearch').oninput = renderBaseTable;
    if (calc$('#calcReactorFilter')) calc$('#calcReactorFilter').onchange = renderBaseTable;
    if (calc$('#calcFrom')) calc$('#calcFrom').oninput = renderBaseTable;
    if (calc$('#calcTo')) calc$('#calcTo').oninput = renderBaseTable;

    if (calc$('#calcClearDates')) {
        calc$('#calcClearDates').onclick = () => {
            if (calc$('#calcFrom')) calc$('#calcFrom').value = '';
            if (calc$('#calcTo')) calc$('#calcTo').value = '';
            renderBaseTable();
        };
    }

    if (calc$('#calcSyncBtn')) {
        calc$('#calcSyncBtn').onclick = syncDirectFromFile;
    }

    if (calc$('#calcExportCsv')) {
        calc$('#calcExportCsv').onclick = exportBaseTableCsv;
    }

    // Sub-tab button wiring
    document.querySelectorAll('.table-tabs .table-tab').forEach(btn => {
        btn.onclick = () => switchSubtab(btn.dataset.subtab);
    });

    // Cross-tab / storage updates
    window.addEventListener('storage', e => {
        if (e.key === 'dhaOnlineState') {
            loadFromOnlineState();
        }
    });
});
