from pathlib import Path
from backend.services.online_analysis_service import process_online_file, ONLINE_COLUMNS

EXCLUDED_ONLINE_COLUMNS = [
    "01i14FIC01",
    "01i14FIC02",
    "01i14FIC03",
    "01i14FIC04",
    "01i14FIC05",
    "01i14FIC06",
    "01i14FIC07",
    "01i14FIC08",
]

EXCLUDED_SET = set(EXCLUDED_ONLINE_COLUMNS)


def filter_base_table_columns(columns):
    """Return columns after excluding the 8 FIC columns."""
    return [col for col in columns if col not in EXCLUDED_SET]


def extract_base_table_data(online_data):
    """
    Extracts Base table data from an Online Analysis payload dictionary.
    Excludes '01i14FIC01' through '01i14FIC08' from columns and all records.
    """
    if not online_data or not isinstance(online_data, dict):
        return {
            "columns": [],
            "rows": [],
            "record_count": 0,
            "source_file": "",
            "excluded_columns": EXCLUDED_ONLINE_COLUMNS,
        }

    raw_columns = online_data.get("columns", [])
    if not raw_columns and online_data.get("rows"):
        raw_columns = list(online_data["rows"][0].keys())

    filtered_columns = filter_base_table_columns(raw_columns)
    raw_rows = online_data.get("rows", [])

    filtered_rows = []
    for row in raw_rows:
        filtered_rows.append({col: row.get(col) for col in filtered_columns})

    return {
        "columns": filtered_columns,
        "rows": filtered_rows,
        "record_count": len(filtered_rows),
        "source_file": online_data.get("source_file", ""),
        "excluded_columns": EXCLUDED_ONLINE_COLUMNS,
    }


def process_base_table_file(file_path):
    """
    Directly processes an Online Analysis SystemTxt file and extracts
    the Base Table dataset (omitting the 8 FIC columns).
    """
    online_data = process_online_file(file_path)
    return extract_base_table_data(online_data)
