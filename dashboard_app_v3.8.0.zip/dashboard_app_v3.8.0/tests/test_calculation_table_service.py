import pytest
from app import create_app
from backend.services.calculation_table_service import (
    EXCLUDED_ONLINE_COLUMNS,
    filter_base_table_columns,
    extract_base_table_data,
    process_base_table_file,
)
from backend.services.online_analysis_service import ONLINE_COLUMNS


def test_excluded_columns_list():
    assert len(EXCLUDED_ONLINE_COLUMNS) == 8
    for i in range(1, 9):
        assert f"01i14FIC0{i}" in EXCLUDED_ONLINE_COLUMNS


def test_filter_base_table_columns():
    all_cols = ["DateTime", "Reactor", *ONLINE_COLUMNS[2:]]
    filtered = filter_base_table_columns(all_cols)

    # Must NOT contain any of the 8 FIC columns
    for exc in EXCLUDED_ONLINE_COLUMNS:
        assert exc not in filtered

    # Must contain the other columns
    assert "DateTime" in filtered
    assert "Reactor" in filtered
    assert "10i1TIC02" in filtered
    assert "10i2TIC02" in filtered
    assert "01i14FI01" in filtered  # Retained
    assert "10i1FIC01" in filtered  # Retained
    assert "ESTD_H2" in filtered    # Retained
    assert "ESTD_N2" in filtered    # Retained
    assert len(filtered) == len(all_cols) - 8


def test_extract_base_table_data():
    online_mock = {
        "columns": [
            "DateTime",
            "Reactor",
            "10i1TIC02",
            "01i14FIC01",
            "01i14FIC02",
            "01i14FI01",
            "ESTD_H2",
        ],
        "rows": [
            {
                "DateTime": "2026-09-04 16:20:46",
                "Reactor": "R1",
                "10i1TIC02": 200.0,
                "01i14FIC01": 680.78,
                "01i14FIC02": 682.06,
                "01i14FI01": 0.297,
                "ESTD_H2": 20.19,
            }
        ],
        "record_count": 1,
        "source_file": "mock.txt",
    }

    base_table = extract_base_table_data(online_mock)
    assert base_table["record_count"] == 1
    assert "01i14FIC01" not in base_table["columns"]
    assert "01i14FIC02" not in base_table["columns"]
    assert "01i14FIC01" not in base_table["rows"][0]
    assert "01i14FIC02" not in base_table["rows"][0]
    assert base_table["rows"][0]["DateTime"] == "2026-09-04 16:20:46"
    assert base_table["rows"][0]["Reactor"] == "R1"
    assert base_table["rows"][0]["01i14FI01"] == 0.297
    assert base_table["rows"][0]["ESTD_H2"] == 20.19


def test_process_base_table_file(tmp_path):
    source = tmp_path / "SystemTxt.txt"
    values = [
        "10.08.2026 14:30:00",
        "R3",
        "1", "2", "3", "4", "5", "6", "7", "8",
        "9", "10", "11", "12", "13", "14", "15",
        "16", "17", "18", "19", "20", "21",
    ]
    source.write_text(
        "\t".join(ONLINE_COLUMNS) + "\n" + "\t".join(values) + "\n", encoding="utf-8"
    )

    result = process_base_table_file(source)
    assert result["record_count"] == 1
    assert "DateTime" in result["columns"]
    assert "Reactor" in result["columns"]
    for exc in EXCLUDED_ONLINE_COLUMNS:
        assert exc not in result["columns"]
        assert exc not in result["rows"][0]


def test_api_process_calculation_base():
    app = create_app({"TESTING": True})
    client = app.test_client()

    payload = {
        "columns": ["DateTime", "Reactor", "01i14FIC01", "ESTD_H2"],
        "rows": [
            {"DateTime": "2026-09-04 16:20:46", "Reactor": "R1", "01i14FIC01": 680.78, "ESTD_H2": 20.19}
        ],
        "source_file": "test.txt",
    }
    res = client.post("/api/process-calculation-base", json=payload)
    assert res.status_code == 200
    data = res.get_json()
    assert data["record_count"] == 1
    assert "01i14FIC01" not in data["columns"]
    assert data["rows"][0]["Reactor"] == "R1"
    assert data["rows"][0]["ESTD_H2"] == 20.19
