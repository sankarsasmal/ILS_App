## Changelog

### 1.3.0 - 2026-09-08
- Extracted the per-file Unknowns value from `CARBON_TABULAR(%WGT)!K21`.
- Added `Unknowns` to each component row returned by the XLS loader.
- Added the `Unknowns` column to the consolidated DHA Data table.
- Added a loader unit test covering K21 extraction and repetition across the five component rows.

### 1.2.0 - 2026-09-08
- Added a Components filter dropdown to the DHA Data table.
- Added Paraffin, I-Paraffins, Aromatics, Naphthenes, and Olefins multi-select options.
- Added Select all and Clear controls and an active-filter summary.
- Preserved text search and folder processing behavior.
- Added safer JSON response handling for API errors.
